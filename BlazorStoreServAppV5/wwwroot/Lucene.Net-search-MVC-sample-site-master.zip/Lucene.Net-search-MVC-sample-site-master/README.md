
# Simple Lucene.Net sample search site - v.1.5

#### Visual Studio 2012 project - includes MVC and WebForms examples

This project is an illustration for my [CodeProject.com](http://codeproject.com) article:

["Lucene.Net ultra fast search for MVC or WebForms site => made easy!"](http://www.codeproject.com/Articles/320219/Lucene-Net-ultra-fast-search-for-MVC-or-WebForms)

By [Mikhail Tsennykh, 2011-2013](http://www.codeproject.com/Members/Mikhail-T)