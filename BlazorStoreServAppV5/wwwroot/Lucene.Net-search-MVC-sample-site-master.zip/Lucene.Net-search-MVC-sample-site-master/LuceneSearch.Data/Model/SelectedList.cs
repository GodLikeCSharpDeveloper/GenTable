﻿namespace LuceneSearch.Model {
  public class SelectedList {
    public string Value { get; set; }
    public string Text { get; set; }
  }
}